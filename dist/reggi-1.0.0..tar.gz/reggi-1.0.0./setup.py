from distutils.core import setup

setup(
    name='reggi',
    version= '1.0.0.',
    py_modules =['reggi','aufruf']
    )