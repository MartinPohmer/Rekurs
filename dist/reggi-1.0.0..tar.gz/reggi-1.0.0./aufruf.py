import reggi


meine =  [51,2,3,3,4,["martin","steffi","iuu",["ende","aus"]]]
reggi.print_lvl(meine)
